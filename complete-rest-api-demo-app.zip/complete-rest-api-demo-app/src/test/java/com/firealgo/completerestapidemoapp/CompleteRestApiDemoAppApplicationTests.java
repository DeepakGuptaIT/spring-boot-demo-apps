package com.firealgo.completerestapidemoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompleteRestApiDemoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
