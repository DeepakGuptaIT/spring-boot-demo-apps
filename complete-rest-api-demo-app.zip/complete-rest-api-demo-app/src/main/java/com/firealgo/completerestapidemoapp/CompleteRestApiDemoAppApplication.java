package com.firealgo.completerestapidemoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompleteRestApiDemoAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompleteRestApiDemoAppApplication.class, args);
	}

}
