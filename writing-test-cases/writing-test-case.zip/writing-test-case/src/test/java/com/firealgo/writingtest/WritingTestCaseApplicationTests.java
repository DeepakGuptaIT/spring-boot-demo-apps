package com.firealgo.writingtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WritingTestCaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
