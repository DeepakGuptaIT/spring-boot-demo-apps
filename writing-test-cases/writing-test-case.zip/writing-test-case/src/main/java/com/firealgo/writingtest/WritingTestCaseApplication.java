package com.firealgo.writingtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WritingTestCaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(WritingTestCaseApplication.class, args);
	}

}
